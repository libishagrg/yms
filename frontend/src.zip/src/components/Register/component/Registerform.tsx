import axios from "axios";
import React from "react";

export default function Registerform() {
  const [registerInfo, setRegisterInfo] = React.useState<{
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    role: string;
  }>({
    firstname: "",
    lastname: "",
    email: "",
    password: "",
    role: "",
  });

  function handleChange(event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    const { name, value } = event.target;
    setRegisterInfo((prevInfo) => ({
      ...prevInfo,
      [name]: value,
    }));
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    console.log("Register Info:", registerInfo);
    try {
      const response = await axios.post("http://localhost:5140/register", registerInfo);
      console.log("Register Response:", response.data);
    } catch (error) {
      console.error("Register Error:", error);
    }
    console.log("Register Info:", registerInfo);
  }

  return (
    <form className="register-form" action="dashboard.html" method="get" onSubmit={handleSubmit}> 
      
      <div className="form-row-2">
        <div className="form-group">
          <label className="form-label" htmlFor="firstname">
            First name
          </label>
          <input
            className="form-input"
            type="text"
            id="firstname"
            name="firstname"
            placeholder="John"
            required
            value={registerInfo.firstname}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="lastname">
            Last name
          </label>
          <input
            className="form-input"
            type="text"
            id="lastname"
            name="lastname"
            placeholder="Doe"
            required
            value={registerInfo.lastname}
            onChange={handleChange}
          />
        </div>
      </div>
      <div className="form-group">
        <label className="form-label" htmlFor="email">
          Work email
        </label>
        <input
          className="form-input"
          type="email"
          id="email"
          name="email"
          placeholder="you@company.com"
          required
          value={registerInfo.email}
          onChange={handleChange}
        />
      </div>
      <div className="form-group">
        <label className="form-label" htmlFor="password">
          Password
        </label>
        <input
          className="form-input"
          type="password"
          id="password"
          name="password"
          placeholder="Create a strong password"
          required
          value={registerInfo.password}
          onChange={handleChange}
        />
      </div>
      <div className="form-group">
        <label className="form-label" htmlFor="role">
          Your role
        </label>
        <select className="form-select" id="role" name="role" required value={registerInfo.role} onChange={handleChange}>
          <option value="" disabled>
            Select your role
          </option>
          <option value="yard-manager">Yard Manager</option>
          <option value="operator">Operator</option>
          <option value="supervisor">Supervisor</option>
          <option value="admin">Administrator</option>
        </select>
      </div>
      <div className="checkbox-group">
        <input type="checkbox" id="terms" name="terms" required />
        <label htmlFor="terms">
          I agree to the <a href="#">Terms of Service</a> and{" "}
          <a href="#">Privacy Policy</a>
        </label>
      </div>
      <button type="submit" className="btn-primary">
        Create Account
      </button>
      <p className="login-link">
        Already have an account? <a href="login.html">Sign in</a>
      </p>
    </form>
  );
}
