import React from "react";
import axios from "axios";

export default function Loginform() {
  const [loginInfo, setLoginInfo] = React.useState<{
    email: string;
    password: string;
    rememberMe: boolean;
  }>({
    email: "",
    password: "",
    rememberMe: false,
  });

  function handleChange(event: React.ChangeEvent<HTMLInputElement>) {
    const { name, value, type, checked } = event.target;
    setLoginInfo((prevInfo) => ({
      ...prevInfo,
      [name]: type === "checkbox" ? checked : value,
    }));
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    console.log("Login Info:", loginInfo);
    try {
      const response = await axios.post("http://localhost:5140/login", loginInfo);
      console.log("Login Response:", response.data);
    } catch (error) {
      console.error("Login Error:", error);
    }
  }

  return (
    <form action="dashboard.html" method="get" onSubmit={handleSubmit}>
      <div className="form-group">
        <label className="form-label" htmlFor="email">
          Email address
        </label>
        <input
          className="form-input"
          type="email"
          id="email"
          name="email"
          placeholder="you@company.com"
          required
          value={loginInfo.email}
          onChange={handleChange}
        />
      </div>
      <div className="form-group">
        <label className="form-label" htmlFor="password">
          Password
        </label>
        <input
          className="form-input"
          type="password"
          id="password"
          name="password"
          placeholder="Enter your password"
          required
          value={loginInfo.password}
          onChange={handleChange}
        />
      </div>
      <div className="form-row">
        <div className="checkbox-group">
          <input
            type="checkbox"
            id="remember"
            name="rememberMe"
            checked={loginInfo.rememberMe}
            onChange={handleChange}
          />
          <label htmlFor="remember">Keep me signed in</label>
        </div>
        <a href="forgot-password.html" className="forgot-link">
          Forgot password?
        </a>
      </div>
      <button type="submit" className="btn-primary">
        Sign In
      </button>
    </form>
  );
}
