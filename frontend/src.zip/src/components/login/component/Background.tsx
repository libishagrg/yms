export default function Backgrond() {
  return (
    <>
      <div className="bg-pattern"></div>
      <div className="bg-grid"></div>
      <div className="shape shape-1"></div>
      <div className="shape shape-2"></div>
      <div className="shape shape-3"></div>
    </>
  );
}
