export default function LoginHead(){
  return(
    <div className="brand-header">
          <div className="brand-logo">Exotrac</div>
          <p className="brand-tagline">Smarter Yard Operations</p>
        </div>
  )
}