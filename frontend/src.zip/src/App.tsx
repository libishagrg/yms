import Register from "./components/Register/Register";
import Login from "./components/login/Login";

function App() {

  return (
    <Register />
  )
}

export default App
